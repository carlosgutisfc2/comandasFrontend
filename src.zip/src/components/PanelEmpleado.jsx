import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { styles as estilosBase } from '../styles/PanelEmpleadoStyles.js';

const PanelEmpleado = () => {
  const navigate = useNavigate();
  
  // Estados de control de flujo
  const [vista, setVista] = useState('menu'); // 'menu' o 'formulario'
  const [tipoAccion, setTipoAccion] = useState(''); // 'comandar', 'abrir', 'cerrar'
  const [codigoMesa, setCodigoMesa] = useState('');
  
  // Estados para los Modales de Confirmación y API
  const [mostrarModal, setMostrarModal] = useState(false);
  const [mensajeFeedback, setMensajeFeedback] = useState('');
  const [cargandoApi, setCargandoApi] = useState(false);

  // NUEVOS ESTADOS: Para capturar y mostrar la contraseña devuelta por el servidor
  const [mostrarModalContrasena, setMostrarModalContrasena] = useState(false);
  const [contrasenaRecibida, setContrasenaRecibida] = useState('');

  // 1. 🔒 CORTAFUEGOS DE SEGURIDAD: Verificación de Token y Rol
  useEffect(() => {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');

    if (!token || role !== 'EMPLEADO') {
      console.warn("Acceso denegado. Se requiere cuenta de empleado.");
      localStorage.clear();
      navigate('/empleado');
    }
  }, [navigate]);

  const handleSeleccionarAccion = (accion) => {
    setTipoAccion(accion);
    setCodigoMesa('');
    setMensajeFeedback('');
    setVista('formulario');
  };

  const handleProcesarFormulario = (e) => {
    e.preventDefault();
    if (!codigoMesa.trim()) return;

    if (tipoAccion === 'comandar') {
      localStorage.setItem('numMesa', codigoMesa.trim().toUpperCase());
      navigate('/carta');
    } else {
      setMostrarModal(true);
    }
  };

  // 🚀 PETICIÓN POST AL BACKEND DIRIGIDA A MESA_CONTROLLER
  const handleConfirmarAccionBackend = async () => {
    const token = localStorage.getItem('token');
    const mesaFormateada = codigoMesa.trim().toUpperCase();
    const endpoint = tipoAccion === 'abrir' ? 'crear' : 'cerrar';
    
    setMostrarModal(false);
    setCargandoApi(true);
    setMensajeFeedback('');

    try {
      const config = { headers: { 'Authorization': `Bearer ${token}` } };
      const url = `http://localhost:8080/mesas/${mesaFormateada}/${endpoint}`;
      
      const response = await axios.post(url, {}, config);

      if (response.status === 200 || response.status === 201) {
        if (tipoAccion === 'abrir') {
          // Capturamos el String plano que devuelve tu backend (la contraseña)
          setContrasenaRecibida(response.data);
          setMostrarModalContrasena(true);
        } else {
          // Flujo normal para el cierre de mesa
          setMensajeFeedback(`✅ ¡Mesa ${mesaFormateada} cerrada con éxito!`);
          setCodigoMesa('');
          setTimeout(() => setVista('menu'), 2000); 
          setCargandoApi(false);
        }
      }
    } catch (err) {
      console.error(`Error al ejecutar ${endpoint} mesa:`, err);
      setCargandoApi(false);
      if (!err.response) {
        setMensajeFeedback(`❌ Error de Red: Revisa que Spring Boot esté encendido y tenga @CrossOrigin.`);
      } else {
        setMensajeFeedback(
          `❌ Error ${err.response.status}: ${err.response.data?.mensaje || 'No se pudo realizar la acción.'}`
        );
      }
    }
  };

  return (
    <div style={estilosBase.wrapper}>
      
      {/* HEADER */}
      <div style={estilosBase.header}>
        <h2 style={estilosBase.title}>Panel de Control</h2>
        <p style={estilosBase.subtitle}>Gestión operativa para el personal de servicio</p>
      </div>

      {/* ALERTAS EN PANTALLA */}
      {mensajeFeedback && (
        <div style={{
          ...estilosBase.tableCard, 
          padding: '14px', 
          marginBottom: '20px', 
          backgroundColor: mensajeFeedback.includes('✅') ? '#d4edda' : '#f8d7da',
          color: mensajeFeedback.includes('✅') ? '#155724' : '#721c24',
          borderColor: mensajeFeedback.includes('✅') ? '#c3e6cb' : '#f5c6cb',
          maxWidth: '500px',
          textAlign: 'center'
        }}>
          <strong>{mensajeFeedback}</strong>
        </div>
      )}

      {/* REJILLA PRINCIPAL DE 4 CUADRADOS */}
      {vista === 'menu' ? (
        <div style={{ ...estilosBase.gridMenu, gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', maxWidth: '800px' }}>
          
          <div style={estilosBase.menuSquare} onClick={() => handleSeleccionarAccion('comandar')}>
            <div style={{ ...estilosBase.iconWrapper, backgroundColor: '#e7f5ff' }}>🍽️</div>
            <h3 style={estilosBase.squareTitle}>Comandar Mesa</h3>
            <p style={estilosBase.squareDesc}>Abrir la carta digital para marchar comandas de platos.</p>
          </div>

          <div style={estilosBase.menuSquare} onClick={() => navigate('/gestion-pedidos')}>
            <div style={{ ...estilosBase.iconWrapper, backgroundColor: '#f4fce3' }}>📋</div>
            <h3 style={estilosBase.squareTitle}>Pedidos Globales</h3>
            <p style={estilosBase.squareDesc}>Monitor de cocina para ver el estado de todas las mesas.</p>
          </div>

          <div style={estilosBase.menuSquare} onClick={() => handleSeleccionarAccion('abrir')}>
            <div style={{ ...estilosBase.iconWrapper, backgroundColor: '#ebfbee' }}>🟢</div>
            <h3 style={estilosBase.squareTitle}>Abrir Mesa</h3>
            <p style={estilosBase.squareDesc}>Habilitar e inicializar sesión para una nueva mesa física.</p>
          </div>

          <div style={estilosBase.menuSquare} onClick={() => handleSeleccionarAccion('cerrar')}>
            <div style={{ ...estilosBase.iconWrapper, backgroundColor: '#fff5f5' }}>🔴</div>
            <h3 style={estilosBase.squareTitle}>Cerrar Mesa</h3>
            <p style={estilosBase.squareDesc}>Finalizar cuenta y liberar el estado ocupado de la mesa.</p>
          </div>

        </div>
      ) : (
        /* FORMULARIO DE TEXTO */
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <button style={estilosBase.backBtn} onClick={() => setVista('menu')} disabled={cargandoApi}>
            ⬅️ Volver al panel
          </button>
          
          <div style={estilosBase.tableCard}>
            <div style={{ fontSize: '2rem', marginBottom: '10px' }}>
              {tipoAccion === 'comandar' ? '📝' : tipoAccion === 'abrir' ? '🔓' : '🔒'}
            </div>
            <h3 style={{ margin: '0 0 6px 0', fontSize: '1.2rem', color: '#212529', textTransform: 'capitalize' }}>
              {tipoAccion === 'comandar' ? 'Asignar Comanda' : `${tipoAccion} mesa`}
            </h3>
            <p style={{ margin: 0, fontSize: '0.85rem', color: '#6c757d' }}>
              Introduce el identificador de la mesa sobre la que deseas operar
            </p>
            
            <form onSubmit={handleProcesarFormulario}>
              <input
                type="text"
                placeholder="Código de Mesa (Ej: MESA1)"
                value={codigoMesa}
                onChange={(e) => setCodigoMesa(e.target.value)}
                required
                style={estilosBase.inputMesa}
                disabled={cargandoApi}
                autoFocus
              />
              <button 
                type="submit" 
                style={{
                  ...estilosBase.submitMesaBtn,
                  backgroundColor: tipoAccion === 'cerrar' ? '#fa5252' : tipoAccion === 'abrir' ? '#2b8a3e' : '#007bff'
                }}
                disabled={cargandoApi}
              >
                {cargandoApi ? 'Procesando...' : 'Continuar Acción'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 🖥️ MODAL DE CONFIRMACIÓN PRE-ENVÍO */}
      {mostrarModal && (
        <div style={styles.modalOverlay}>
          <div style={styles.modalContent}>
            <h3 style={{ margin: '0 0 14px 0', fontSize: '1.25rem', color: '#212529' }}>⚠️ Confirmación Requerida</h3>
            
            <p style={{ fontSize: '0.95rem', color: '#495057', lineHeight: '1.5', margin: '0 0 20px 0' }}>
              ¿Estás seguro de que deseas {' '}
              {tipoAccion === 'cerrar' ? (
                <span style={styles.badgeCerrar}>CERRAR</span>
              ) : (
                <span style={styles.badgeAbrir}>ABRIR</span>
              )}
              {' '} la mesa <strong>{codigoMesa.toUpperCase()}</strong> en el sistema del restaurante?
            </p>

            <div style={styles.modalActions}>
              <button style={styles.cancelarBtn} onClick={() => setMostrarModal(false)}>
                Cancelar
              </button>
              <button 
                style={{
                  ...styles.confirmarBtn,
                  backgroundColor: tipoAccion === 'cerrar' ? '#e03131' : '#234e23'
                }} 
                onClick={handleConfirmarAccionBackend}
              >
                Confirmar Ejecución
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🔑 NUEVO MODAL EMERGENTE: Muestra la Contraseña devuelta por el servidor */}
      {mostrarModalContrasena && (
        <div style={styles.modalOverlay}>
          <div style={styles.modalContent}>
            <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>🔑</div>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '1.3rem', color: '#212529' }}>Mesa Inicializada</h3>
            
            <p style={{ fontSize: '0.92rem', color: '#495057', margin: '0 0 16px 0', lineHeight: '1.4' }}>
              Se ha abierto correctamente la mesa. La contraseña de acceso generada por el servidor es:
            </p>

            {/* Contenedor destacado para la contraseña */}
            <div style={styles.passwordContainer}>
              {contrasenaRecibida}
            </div>

            <p style={{ fontSize: '0.82rem', color: '#868e96', margin: '16px 0 24px 0', fontStyle: 'italic' }}>
              Por favor, comunica esta clave a la mesa física para que puedan escanear el QR y pedir.
            </p>

            <button 
              style={styles.btnCerrarPassword} 
              onClick={() => {
                setMostrarModalContrasena(false);
                setContrasenaRecibida('');
                setCodigoMesa('');
                setVista('menu');
                setCargandoApi(false);
              }}
            >
              Cerrar y Finalizar
            </button>
          </div>
        </div>
      )}
      
      {vista === 'menu' && (
        <button 
          style={{ marginTop: '40px', padding: '10px 20px', backgroundColor: '#fff', border: '1px solid #ffe3e3', color: '#fa5252', borderRadius: '10px', cursor: 'pointer', fontWeight: '700', fontSize: '0.85rem' }}
          onClick={() => { localStorage.clear(); navigate('/empleado'); }}
        >
          🚪 Cerrar Sesión de Empleado
        </button>
      )}
    </div>
  );
};

// --- ESTILOS COMPARTIDOS Y PROPIOS DE LAS VENTANAS EMERGENTES ---
const styles = {
  modalOverlay: { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0, 0, 0, 0.4)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 2000, backdropFilter: 'blur(2px)' },
  modalContent: { backgroundColor: '#fff', padding: '24px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(0,0,0,0.15)', width: '90%', maxWidth: '400px', textAlign: 'center', boxSizing: 'border-box', border: '1px solid #e9ecef' },
  badgeCerrar: { backgroundColor: '#fa5252', color: '#fff', padding: '4px 10px', borderRadius: '4px', fontWeight: '800', fontSize: '0.9rem', display: 'inline-block' },
  badgeAbrir: { backgroundColor: '#28a745', color: '#fff', padding: '4px 10px', borderRadius: '4px', fontWeight: '800', fontSize: '0.9rem', display: 'inline-block' },
  modalActions: { display: 'flex', gap: '12px', justifyContent: 'center', marginTop: '10px' },
  cancelarBtn: { padding: '10px 18px', backgroundColor: '#f1f3f5', color: '#495057', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: '600', fontSize: '0.88rem' },
  confirmarBtn: { padding: '10px 18px', color: '#fff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: '700', fontSize: '0.88rem' },
  
  // Estilos exclusivos para visualizar la Contraseña
  passwordContainer: {
    backgroundColor: '#f1f3f5',
    border: '2px dashed #ced4da',
    borderRadius: '12px',
    padding: '14px 20px',
    fontSize: '1.6rem',
    fontWeight: '800',
    color: '#1c7ed6',
    letterSpacing: '2px',
    margin: '10px 0',
    fontFamily: 'monospace, Courier'
  },
  btnCerrarPassword: {
    width: '100%',
    padding: '12px',
    backgroundColor: '#212529',
    color: '#fff',
    border: 'none',
    borderRadius: '10px',
    fontSize: '0.95rem',
    fontWeight: '700',
    cursor: 'pointer',
    transition: 'background-color 0.1s ease'
  }
};

export default PanelEmpleado;